//EXPERIMENT NO: 9
//EXPERIMENT NAME: SINGLE PASS MACRO PROCESSOR
//DATE: 08/02/2022
//AIM: TO IMPLEMENT A SINGLE PASS MACRO PROCESSOR
//AUTHOR NAME: S SAMEEM
//ROLL NUMBER: 57

#include<stdio.h>
#include<string.h>
#include<stdlib.h>

void reverse(char str[], int length)
{
    int start=0;
    int end=length-1;
    while (start<end)
    {
        char t;
        t=str[start];
        str[start]=str[end];
        str[end]=t;
        start++;
        end--;
    }
}

char* itoa(int num, char* str, int base)
{
    int i=0;
    if (num==0)
    {
        str[i++]='0';
        str[i]='\0';
        return str;
    }
    while (num!=0)
    {
        int rem=num%base;
        str[i++]=(rem>9)?(rem-10)+'a':rem+'0';
        num=num/base;
    }
    str[i]='\0';
    reverse(str, i);
    return str;
}

int main()
{
	FILE *f1,*f2,*f3,*f4,*f5;
	int len,i,pos=1;
	char	arg[20],mne[20],opnd[20],la[20],name[20],mne1[20],opnd1[20],pos1[10],pos2[10];
	char s;
	f1=fopen("input.txt","r");
	f2=fopen("namtab.txt","w+");
	f3=fopen("deftab.txt","w+");
	f4=fopen("argtab.txt","w+");
	f5=fopen("op.txt","w+");
	fscanf(f1,"%s%s%s",la,mne,opnd);
	while(strcmp(mne,"END")!=0)
	{
		if(strcmp(mne,"MACRO")==0)
	   	{
			fprintf(f2,"%s\n",la);
		  	fseek(f2,SEEK_SET,0);
		  	fprintf(f3,"%s\t%s\n",la,opnd);
		  	fscanf(f1,"%s%s%s",la,mne,opnd);
		  	while(strcmp(mne,"MEND")!=0)
		  	{
			 	if(opnd[0]=='&')
			 	{
			     	itoa(pos,pos1,10);
			     	strcpy(pos2,"?");
			     	strcpy(opnd,strcat(pos2,pos1));
			     	pos=pos+1;
			 	}
			 	fprintf(f3,"%s\t%s\n",mne,opnd);
			 	fscanf(f1,"%s%s%s",la,mne,opnd);
		  	}
		  	fprintf(f3,"%s",mne);
	   	}
	   	else
	   	{
		  	fscanf(f2,"%s",name);
		  	if(strcmp(mne,name)==0)
		  	{
			 	len=strlen(opnd);
			 	for(i=0;i<len;i++)
			 	{
			     	if(opnd[i]!=',')
			         		fprintf(f4,"%c",opnd[i]);
			     	else
			         		fprintf(f4,"\n");
			 	}
			 	fseek(f3,SEEK_SET,0);
			 	fseek(f4,SEEK_SET,0);
			 	fscanf(f3,"%s%s",mne1,opnd1);
			 	fprintf(f5,".\t%s\t%s\n",mne1,opnd);
			 	fscanf(f3,"%s%s",mne1,opnd1);
			 	while(strcmp(mne1,"MEND")!=0)
			 	{
			     	if((opnd1[0]=='?'))
			     	{
			         		fscanf(f4,"%s",arg);
			         		fprintf(f5,"-\t%s\t%s\n",mne1,arg);
			     	}
			     	else
			         		fprintf(f5,"-\t%s\t%s\n",mne1,opnd1);
			     	fscanf(f3,"%s%s",mne1,opnd1);
			 	}
		  	}
		  	else
			 	fprintf(f5,"%s\t%s\t%s\n",la,mne,opnd);
	   	}
	   	fscanf(f1,"%s%s%s",la,mne,opnd);
	}
	fprintf(f5,"%s\t%s\t%s",la,mne,opnd);
	fclose(f1);
	fclose(f2);
	fclose(f3);
	fclose(f4);
	fclose(f5);
	FILE *inp;
  	printf("\n-----INPUT.TXT-----\n");
  	inp=fopen("/home/nwlab7/Sameem/Prg9/input.txt", "r");
  	s=fgetc(inp);
  	while(s!=EOF)
  	{
    		printf("%c",s);
    		s=fgetc(inp);
  	}
  	fclose(inp);

	FILE *nam;
  	printf("\n-----NAMTAB.TXT-----\n");
  	nam=fopen("/home/nwlab7/Sameem/Prg9/namtab.txt", "r");
  	s=fgetc(nam);
  	while(s!=EOF)
  	{
    		printf("%c",s);
    		s=fgetc(nam);
  	}
  	fclose(nam);

	FILE *def;
  	printf("\n-----DEFTAB.TXT-----\n");
  	def=fopen("/home/nwlab7/Sameem/Prg9/deftab.txt", "r");
  	s=fgetc(def);
  	while(s!=EOF)
  	{
    		printf("%c",s);
    		s=fgetc(def);
  	}
  	printf("\n");
  	fclose(def);

	FILE *argu;
  	printf("\n-----ARGTAB.TXT-----\n");
  	argu=fopen("/home/nwlab7/Sameem/Prg9/argtab.txt", "r");
  	s=fgetc(argu);
  	while(s!=EOF)
  	{
    		printf("%c",s);
    		s=fgetc(argu);
  	}
  	printf("\n");
  	fclose(argu);

	FILE *outp;
  	printf("\n-----OUTPUT.TXT-----\n");
  	outp=fopen("/home/nwlab7/Sameem/Prg9/op.txt", "r");
  	s=fgetc(outp);
  	while(s!=EOF)
  	{
    		printf("%c",s);
    		s=fgetc(outp);
  	}
  	printf("\n");
  	fclose(outp);
	
	return 0;
}

/*

input.txt
---------
EX1 MACRO   &A,&B
-   LDA &A
-   STA &B
-   MEND    -
SAMPLE  START   1000
-   EX1 N1,N2
N1  RESW    1
N2  RESW    1
-   END -

namtab.txt
----------
EX1

deftab.txt
----------
EX1	&A,&B
LDA	?1
STA	?2
MEND

argtab.txt
----------
N1
N2

op.txt
------
SAMPLE	START	1000
.	EX1	N1,N2
-	LDA	N1
-	STA	N2
N1	RESW	1
N2	RESW	1
-	END	-

*/
