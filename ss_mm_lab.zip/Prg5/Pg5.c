//EXPERIMENT NO: 5
//EXPERIMENT NAME: PASS ONE OF TWO PASS ASSEMBLER
//DATE: 07/12/2021
//AIM: TO IMPLEMENT PASS ONE ALGORITHM OF TWO PASS ASSEMBLER
//AUTHOR NAME: S SAMEEM
//ROLL NUMBER: 57

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void main()
{
	char opcode[10],operand[10],label[10],mnemonic[10],code[10],s;
	int locctr,start,length;
	FILE *input,*optab,*symbol,*output;

	input=fopen("/home/nwlab7/Sameem/Prg5/input1.txt", "r");
	optab=fopen("/home/nwlab7/Sameem/Prg5/optab1.txt", "r");
	symbol=fopen("/home/nwlab7/Sameem/Prg5/symbol1.txt", "w");
	output=fopen("/home/nwlab7/Sameem/Prg5/output1.txt", "w");

	fscanf(input,"%s\t%s\t%s",label,opcode,operand);

	if(strcmp(opcode,"START")==0)
	{
		start=atoi(operand);
		locctr=start;
		fprintf(output,"\t%s\t%s\t%X\n",label,opcode,locctr+3096);
		fscanf(input,"%s\t%s\t%s",label,opcode,operand);
	}
	else locctr=0;

	while(strcmp(opcode,"END")!=0)
	{
		fprintf(output,"%X\t",locctr+3096);
		if(strcmp(label,"-")!=0)
			fprintf(symbol,"%s\t%X\n",label,locctr+3096);
		fseek(optab,SEEK_SET,0);
		fscanf(optab,"%s\t%s",code,mnemonic);
		while(strcmp(code,"END")!=0)
		{
			if(strcmp(opcode,code)==0)
			{
				locctr+=3; break;
			}
			fscanf(optab,"%s\t%s",code,mnemonic);
		}
		if(strcmp(opcode,"WORD")==0) locctr+=3;
		else if(strcmp(opcode,"RESW")==0) locctr+=(3*(atoi(operand)));
		else if(strcmp(opcode,"RESB")==0) locctr+=atoi(operand);
		else if(strcmp(opcode,"BYTE")==0)
			{
				char ch=operand[0];
				if(strcmp(&ch,"X")==0)
					locctr+=1;
				else
					locctr+=strlen(operand)-3;
			}

		fprintf(output,"%s\t%s\t%s\t\n",label,opcode,operand);
		fscanf(input,"%s\t%s\t%s",label,opcode,operand);
	}
	fprintf(output,"%X\n",locctr+3096);
	fprintf(output,"\t%s\t%s\t%s\n",label,opcode,operand);
	length=locctr-start;

	fclose(input);
	fclose(optab);
	fclose(output);
	fclose(symbol);

	FILE *inp;
	printf("-----INPUT.TXT-----\n");
	inp=fopen("/home/nwlab7/Sameem/Prg5/input1.txt", "r");
	s=fgetc(inp);
	while(s!=EOF)
	{
		printf("%c",s);
		s=fgetc(inp);
	}
	printf("\n");
	fclose(inp);

	FILE *opt;
	printf("-----OPTAB.TXT-----\n");
	opt=fopen("/home/nwlab7/Sameem/Prg5/optab1.txt", "r");
	s=fgetc(opt);
	while(s!=EOF)
	{
		printf("%c",s);
		s=fgetc(opt);
	}
	printf("\n");
	fclose(opt);

	FILE *out;
	printf("-----OUTPUT.TXT-----\n");
	out=fopen("/home/nwlab7/Sameem/Prg5/output1.txt", "r");
	s=fgetc(out);
	while(s!=EOF)
	{
		printf("%c",s);
		s=fgetc(out);
	}
	printf("\n");
	fclose(out);

	FILE *sym;
	printf("-----SYMTAB.TXT-----\n");
	sym=fopen("/home/nwlab7/Sameem/Prg5/symbol1.txt", "r");
	s=fgetc(sym);
	while(s!=EOF)
	{
		printf("%c",s);
		s=fgetc(sym);
	}
	printf("\n");
	fclose(sym); 
	
	printf("The length of code: %d\n",length);
}
