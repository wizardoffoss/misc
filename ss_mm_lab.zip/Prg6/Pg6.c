#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void main()
{
	FILE *fint,*ftab,*flen,*fsym,*fout;
	int op1[10],txtlen,txtlen1,i,j=0,len;
	char add[5],symadd[5],op[5],start[10],temp[30],line[20],label[20],mne[10],operand[10],symtab[10],opmne[10],s;
	fint=fopen("/home/nwlab7/Sameem/Prg6/input.txt","r");
	flen=fopen("/home/nwlab7/Sameem/Prg6/length.txt","r");
	ftab=fopen("/home/nwlab7/Sameem/Prg6/optab.txt","r");
	fsym=fopen("/home/nwlab7/Sameem/Prg6/symbol.txt","r");
	fout=fopen("/home/nwlab7/Sameem/Prg6/output.txt","w");
	fscanf(fint,"%s%s%s%s",add,label,mne,operand);
	if(strcmp(mne,"START")==0)
	{
		strcpy(start,operand);
		fscanf(flen,"%d",&len);
	}
	fprintf(fout,"H^%s^%06d^%X\nT^%06d^12",label,atoi(start),len,atoi(start));
	fscanf(fint,"%s%s%s%s",add,label,mne,operand);
	while(strcmp(mne,"END")!=0)
	{
		fscanf(ftab,"%s%s",opmne,op);
		while(!feof(ftab))
		{
			if(strcmp(mne,opmne)==0)
			{
				while(!feof(fsym))
				{
					fscanf(fsym,"%s%s",symadd,symtab);
					if(strcmp(operand,symtab)==0)
					{
						fprintf(fout,"^%s%s",op,symadd);
						break;
					}
				}
				fseek(fsym,SEEK_SET,0);
				break;
			}
			else
				fscanf(ftab,"%s%s",opmne,op);
		}
		fseek(ftab,SEEK_SET,0);
		if(strcmp(mne,"BYTE")==0||strcmp(mne,"WORD")==0)
		{
			if(strcmp(mne,"WORD")==0)
				fprintf(fout,"^0000%s",operand);
			else
			{
				fprintf(fout,"^");
				len=strlen(operand);
				for(i=2;i<len-1;i++)
					fprintf(fout,"%d",operand[i]);
			}
		}
		fscanf(fint,"%s%s%s%s",add,label,mne,operand);
	}
	fprintf(fout,"\nE^00%s",start);
	fclose(fint);
	fclose(ftab);
	fclose(fsym);
	fclose(flen);
	fclose(fout);
	FILE *out;
	printf("-----INPUT.TXT-----\n");
	out=fopen("/home/nwlab7/Sameem/Prg6/input.txt", "r");
	s=fgetc(out);
	while(s!=EOF)
	{
		printf("%c",s);
		s=fgetc(out);
	}
	printf("\n");
	fclose(out);
	printf("-----OPTAB.TXT-----\n");
	out=fopen("/home/nwlab7/Sameem/Prg6/optab.txt", "r");
	s=fgetc(out);
	while(s!=EOF)
	{
		printf("%c",s);
		s=fgetc(out);
	}
	printf("\n");
	fclose(out);
	printf("-----SYMBTAB.TXT-----\n");
	out=fopen("/home/nwlab7/Sameem/Prg6/symbol.txt", "r");
	s=fgetc(out);
	while(s!=EOF)
	{
		printf("%c",s);
		s=fgetc(out);
	}
	printf("\n\n");
	fclose(out);
	printf("-----OUTPUT.TXT-----\n");
	out=fopen("/home/nwlab7/Sameem/Prg6/output.txt", "r");
	s=fgetc(out);
	while(s!=EOF)
	{
		printf("%c",s);
		s=fgetc(out);
	}
	printf("\n");
	fclose(out);
}